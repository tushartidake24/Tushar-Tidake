
"use client";

import { useState, useEffect, useCallback } from 'react';

export type Transaction = {
  id: string;
  type: 'send' | 'receive' | 'topup' | 'reward';
  amount: number;
  payeeName: string;
  upiId: string;
  timestamp: string;
  status: 'completed' | 'pending' | 'failed';
  note?: string;
  senderName?: string;
};

export type UserProfile = {
  name: string;
  phone: string;
  email: string;
  upiId: string;
  photoUrl: string;
  password?: string;
};

const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx1',
    type: 'send',
    amount: 500,
    payeeName: 'Organic Grocers',
    upiId: 'grocery@upi',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    status: 'completed',
    note: 'Weekly groceries'
  },
  {
    id: 'tx2',
    type: 'receive',
    amount: 1200,
    payeeName: 'Rahul Kumar',
    upiId: 'rahul.k@upi',
    timestamp: new Date(Date.now() - 86400000).toISOString(),
    status: 'completed',
    note: 'Dinner split'
  }
];

const DEFAULT_PROFILE: UserProfile = {
  name: "John Doe",
  phone: "9876543210",
  email: "john.doe@example.com",
  upiId: "john.doe@upipay",
  photoUrl: "https://picsum.photos/seed/avatar1/150/150"
};

export function usePayZen() {
  const [balance, setBalance] = useState<number>(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [pin, setPinState] = useState<string | null>(null);
  const [profile, setProfileState] = useState<UserProfile>(DEFAULT_PROFILE);
  const [rewardsCount, setRewardsCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);

  const loadUserData = useCallback((email: string) => {
    // Load balance
    const storedBalance = localStorage.getItem(`upi_balance_${email}`);
    setBalance(storedBalance ? parseFloat(storedBalance) : 12450.75);

    // Load transactions
    const storedTxs = localStorage.getItem(`upi_txs_${email}`);
    if (storedTxs) {
      setTransactions(JSON.parse(storedTxs));
    } else {
      setTransactions(INITIAL_TRANSACTIONS);
      localStorage.setItem(`upi_txs_${email}`, JSON.stringify(INITIAL_TRANSACTIONS));
    }

    // Load PIN
    const storedPin = localStorage.getItem(`upi_pin_${email}`);
    setPinState(storedPin || "1234");

    // Load Rewards
    const storedRewards = localStorage.getItem(`upi_rewards_${email}`);
    setRewardsCount(storedRewards ? parseInt(storedRewards) : 0);

    // Load Profile
    const accounts = JSON.parse(localStorage.getItem('upi_accounts') || '{}');
    if (accounts[email]) {
      setProfileState(accounts[email]);
    }
  }, []);

  useEffect(() => {
    const activeEmail = localStorage.getItem('upi_active_email');
    if (activeEmail) {
      loadUserData(activeEmail);
    } else {
      // Default fallback for first time users
      setBalance(12450.75);
      setTransactions(INITIAL_TRANSACTIONS);
      setPinState("1234");
    }
    setLoading(false);
  }, [loadUserData]);

  const login = (email: string) => {
    const accounts = JSON.parse(localStorage.getItem('upi_accounts') || '{}');
    if (accounts[email]) {
      localStorage.setItem('upi_active_email', email);
      loadUserData(email);
      return true;
    }
    return false;
  };

  const register = (userData: UserProfile) => {
    const accounts = JSON.parse(localStorage.getItem('upi_accounts') || '{}');
    
    // Check if account already exists
    if (accounts[userData.email]) {
      return login(userData.email);
    }

    // Create new account
    const newAccount = {
      ...userData,
      upiId: `${userData.name.toLowerCase().replace(/\s+/g, '.')}${Math.floor(Math.random() * 100)}@upipay`
    };
    
    accounts[userData.email] = newAccount;
    localStorage.setItem('upi_accounts', JSON.stringify(accounts));
    localStorage.setItem('upi_active_email', userData.email);
    
    // Initialize default data for new user
    localStorage.setItem(`upi_balance_${userData.email}`, "1000.00");
    localStorage.setItem(`upi_txs_${userData.email}`, JSON.stringify([]));
    localStorage.setItem(`upi_pin_${userData.email}`, "1234");
    localStorage.setItem(`upi_rewards_${userData.email}`, "0");
    
    loadUserData(userData.email);
    return true;
  };

  const logout = () => {
    localStorage.removeItem('upi_active_email');
    window.location.href = '/login';
  };

  const updatePin = (newPin: string) => {
    const email = profile.email;
    localStorage.setItem(`upi_pin_${email}`, newPin);
    setPinState(newPin);
  };

  const updateProfile = (newProfile: UserProfile) => {
    const accounts = JSON.parse(localStorage.getItem('upi_accounts') || '{}');
    accounts[newProfile.email] = newProfile;
    localStorage.setItem('upi_accounts', JSON.stringify(accounts));
    setProfileState(newProfile);
  };

  const verifyPin = (inputPin: string) => {
    return inputPin === pin;
  };

  const claimReward = (amount: number) => {
    if (rewardsCount <= 0) return false;
    const email = profile.email;

    const newBalance = balance + amount;
    setBalance(newBalance);
    localStorage.setItem(`upi_balance_${email}`, newBalance.toString());

    const newRewards = rewardsCount - 1;
    setRewardsCount(newRewards);
    localStorage.setItem(`upi_rewards_${email}`, newRewards.toString());

    const newTx: Transaction = {
      id: Math.random().toString(36).substring(7),
      type: 'reward',
      amount,
      payeeName: 'UPI-Payment Rewards',
      upiId: 'rewards@upipay',
      timestamp: new Date().toISOString(),
      status: 'completed',
      note: 'Cashback from scratch card'
    };

    const updatedTxs = [newTx, ...transactions];
    setTransactions(updatedTxs);
    localStorage.setItem(`upi_txs_${email}`, JSON.stringify(updatedTxs));
    return true;
  };

  const sendMoney = (amount: number, payeeName: string, upiId: string, note?: string) => {
    if (balance < amount) return false;
    const email = profile.email;

    const newBalance = balance - amount;
    setBalance(newBalance);
    localStorage.setItem(`upi_balance_${email}`, newBalance.toString());

    const newRewards = rewardsCount + 1;
    setRewardsCount(newRewards);
    localStorage.setItem(`upi_rewards_${email}`, newRewards.toString());

    const newTx: Transaction = {
      id: Math.random().toString(36).substring(7),
      type: 'send',
      amount,
      payeeName,
      upiId,
      timestamp: new Date().toISOString(),
      status: 'completed',
      note: note || '',
      senderName: profile.name
    };
    
    const updatedTxs = [newTx, ...transactions];
    setTransactions(updatedTxs);
    localStorage.setItem(`upi_txs_${email}`, JSON.stringify(updatedTxs));
    return true;
  };

  const clearTransactions = () => {
    const email = profile.email;
    localStorage.setItem(`upi_txs_${email}`, JSON.stringify([]));
    setTransactions([]);
  };

  const deleteTransaction = (id: string) => {
    const email = profile.email;
    const updatedTxs = transactions.filter(tx => tx.id !== id);
    setTransactions(updatedTxs);
    localStorage.setItem(`upi_txs_${email}`, JSON.stringify(updatedTxs));
  };

  return { 
    balance, 
    transactions, 
    loading, 
    sendMoney, 
    claimReward,
    rewardsCount,
    pin, 
    updatePin, 
    verifyPin,
    profile,
    updateProfile,
    clearTransactions,
    deleteTransaction,
    login,
    register,
    logout
  };
}
