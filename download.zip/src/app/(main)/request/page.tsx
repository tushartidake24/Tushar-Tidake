
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  ArrowLeft, 
  Send, 
  Smartphone, 
  IndianRupee, 
  MessageSquare, 
  CheckCircle2, 
  Loader2,
  ShieldCheck
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function RequestPage() {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const { toast } = useToast();
  const router = useRouter();

  const handleSendRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (phoneNumber.length < 10) {
      toast({ variant: "destructive", title: "Invalid Phone Number", description: "Please enter a valid 10-digit mobile number" });
      return;
    }

    const val = parseFloat(amount);
    if (isNaN(val) || val <= 0) {
      toast({ variant: "destructive", title: "Invalid amount" });
      return;
    }

    setIsSending(true);
    
    // Simulate sending SMS payment request
    setTimeout(() => {
      setIsSending(false);
      setIsSuccess(true);
      toast({
        title: "SMS Request Sent",
        description: `A payment request of ₹${val} has been sent to ${phoneNumber} via secure SMS.`,
      });
    }, 2000);
  };

  if (isSuccess) {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] space-y-6 text-center animate-in fade-in zoom-in">
        <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center text-primary">
          <CheckCircle2 className="w-16 h-16" />
        </div>
        <div className="space-y-2">
          <h2 className="text-3xl font-bold">Request Sent</h2>
          <p className="text-muted-foreground text-lg px-6">
            An SMS link has been sent to <span className="font-bold text-foreground">{phoneNumber}</span> to pay you ₹{parseFloat(amount).toLocaleString('en-IN')}.
          </p>
        </div>
        <div className="flex flex-col w-full max-w-xs gap-3">
          <Button 
            onClick={() => router.push('/dashboard')}
            className="bg-primary rounded-full h-12 text-lg"
          >
            Back to Dashboard
          </Button>
          <Button 
            variant="outline"
            onClick={() => {
              setIsSuccess(false);
              setPhoneNumber("");
              setAmount("");
              setNote("");
            }}
            className="rounded-full h-12 text-lg border-primary text-primary"
          >
            Send Another Request
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="rounded-full">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <h1 className="text-2xl font-bold">Request Money</h1>
      </div>

      <Card className="border-none shadow-xl overflow-hidden">
        <CardHeader className="bg-slate-50 border-b">
          <CardTitle className="text-lg">Send Payment Request</CardTitle>
          <CardDescription>We'll send a secure payment link via SMS to the recipient.</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <form onSubmit={handleSendRequest} className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="phone">Recipient Phone Number</Label>
              <div className="relative">
                <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="phone"
                  type="tel"
                  placeholder="Enter 10-digit number"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
                  required
                  className="h-14 rounded-xl pl-12 text-lg"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount Requested (₹)</Label>
              <div className="relative">
                <IndianRupee className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <Input
                  id="amount"
                  type="number"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  required
                  className="h-16 rounded-xl pl-12 text-2xl font-bold border-2 focus:border-primary"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="note">Message for Recipient (Optional)</Label>
              <div className="relative">
                <MessageSquare className="absolute left-4 top-4 w-5 h-5 text-muted-foreground" />
                <Input
                  id="note"
                  placeholder="e.g. Lunch split for yesterday"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  className="h-14 rounded-xl pl-12"
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={isSending}
              className="w-full h-14 rounded-full text-lg bg-primary hover:bg-primary/90 mt-4 shadow-lg shadow-primary/20"
            >
              {isSending ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin" /> Sending SMS...
                </div>
              ) : (
                <span className="flex items-center gap-2">
                  Send SMS Request <Send className="w-4 h-4" />
                </span>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>
      
      <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100 space-y-2">
        <h4 className="font-bold text-sm text-primary flex items-center gap-2">
           <ShieldCheck className="w-4 h-4" /> Secure Requests
        </h4>
        <p className="text-xs text-blue-700 leading-relaxed">
          UPI-Payment secure requests generate a unique, time-limited link. When the recipient clicks the link in their SMS, they can pay you instantly via any UPI app or their UPI-Payment wallet.
        </p>
      </div>
    </div>
  );
}
