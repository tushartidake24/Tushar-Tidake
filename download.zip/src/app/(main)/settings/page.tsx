
"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  ArrowLeft, 
  User, 
  Shield, 
  Bell, 
  CreditCard, 
  HelpCircle, 
  LogOut,
  ChevronRight,
  Globe,
  Moon,
  Lock,
  CheckCircle2,
  Loader2,
  Mail,
  Smartphone,
  Edit,
  RefreshCw,
  Upload
} from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { usePayZen } from "@/hooks/use-pay-zen";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";

export default function SettingsPage() {
  const router = useRouter();
  const { pin, updatePin, profile, updateProfile, loading } = usePayZen();
  const { toast } = useToast();
  
  const [newPin, setNewPin] = useState("");
  const [isUpdating, setIsUpdating] = useState(false);
  
  // Profile edit state
  const [editName, setEditName] = useState("");
  const [editEmail, setEditEmail] = useState("");
  const [editPhone, setEditPhone] = useState("");
  const [editPhotoUrl, setEditPhotoUrl] = useState("");
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (profile) {
      setEditName(profile.name);
      setEditEmail(profile.email);
      setEditPhone(profile.phone);
      setEditPhotoUrl(profile.photoUrl);
    }
  }, [profile]);

  const handleUpdatePin = () => {
    if (newPin.length < 4) {
      toast({ variant: "destructive", title: "Invalid PIN", description: "PIN must be at least 4 digits." });
      return;
    }
    setIsUpdating(true);
    setTimeout(() => {
      updatePin(newPin);
      setIsUpdating(false);
      setNewPin("");
      toast({ title: "PIN Updated", description: "Your UPI PIN has been changed successfully." });
    }, 1000);
  };

  const handleSaveProfile = () => {
    if (!editName || !editPhone) {
      toast({ variant: "destructive", title: "Incomplete details" });
      return;
    }
    setIsUpdating(true);
    setTimeout(() => {
      updateProfile({
        ...profile,
        name: editName,
        email: editEmail,
        phone: editPhone,
        photoUrl: editPhotoUrl
      });
      setIsUpdating(false);
      setIsProfileOpen(false);
      toast({ title: "Profile Updated", description: "Your personal information has been saved." });
    }, 1000);
  };

  const handleShufflePhoto = () => {
    const seeds = ['avatar1', 'avatar2', 'avatar3', 'avatar4', 'avatar5', 'avatar6', 'avatar7', 'avatar8'];
    const randomSeed = seeds[Math.floor(Math.random() * seeds.length)];
    const currentSeed = editPhotoUrl.split('/seed/')[1]?.split('/')[0];
    
    // Prevent same seed twice
    let finalSeed = randomSeed;
    if (finalSeed === currentSeed) {
      finalSeed = seeds[(seeds.indexOf(randomSeed) + 1) % seeds.length];
    }
    
    setEditPhotoUrl(`https://picsum.photos/seed/${finalSeed}/150/150`);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) { // 2MB limit for local storage convenience
        toast({
          variant: "destructive",
          title: "File too large",
          description: "Please select an image smaller than 2MB."
        });
        return;
      }

      const reader = new FileReader();
      reader.onloadend = () => {
        setEditPhotoUrl(reader.result as string);
        toast({
          title: "Photo Selected",
          description: "Click Save Changes to apply your new profile picture."
        });
      };
      reader.readAsDataURL(file);
    }
  };

  const handlePaymentMethods = () => {
    toast({
      title: "Payment Methods",
      description: "You have 1 linked bank account and 2 credit cards. Verification active."
    });
  };

  if (loading) return <div className="p-8 text-center">Loading settings...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="rounded-full">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <h1 className="text-2xl font-bold">Settings</h1>
      </div>

      <div className="flex flex-col items-center py-6 space-y-4">
        <div className="relative">
          <Avatar className="w-24 h-24 border-4 border-white shadow-xl">
            <AvatarImage src={profile.photoUrl} />
            <AvatarFallback>{profile.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="absolute bottom-0 right-0 p-1 bg-primary text-white rounded-full border-2 border-white cursor-pointer" onClick={() => setIsProfileOpen(true)}>
            <Edit className="w-4 h-4" />
          </div>
        </div>
        <div className="text-center space-y-1">
          <h2 className="text-xl font-bold">{profile.name}</h2>
          <p className="text-sm text-muted-foreground">{profile.upiId}</p>
          <p className="text-xs text-muted-foreground">+91 {profile.phone}</p>
        </div>
      </div>

      <div className="space-y-8">
        {/* Account Group */}
        <div className="space-y-3">
          <h3 className="px-4 text-xs font-bold text-muted-foreground uppercase tracking-widest">Account</h3>
          <div className="bg-white rounded-3xl overflow-hidden shadow-sm border">
            {/* Personal Info Dialog */}
            <Dialog open={isProfileOpen} onOpenChange={setIsProfileOpen}>
              <DialogTrigger asChild>
                <div className="flex items-center justify-between p-4 hover:bg-slate-50 cursor-pointer transition-colors group">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                      <User className="w-5 h-5" />
                    </div>
                    <span className="text-sm font-bold">Personal Information</span>
                  </div>
                  <ChevronRight className="w-5 h-5 text-muted-foreground" />
                </div>
              </DialogTrigger>
              <DialogContent className="rounded-3xl max-w-[90vw] sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Edit Profile</DialogTitle>
                  <DialogDescription>Update your personal details for UPI-Payment.</DialogDescription>
                </DialogHeader>
                <div className="space-y-6 py-4">
                  <div className="flex flex-col items-center gap-4">
                    <div className="relative group">
                      <Avatar className="w-24 h-24 border-2 border-primary overflow-hidden">
                        <AvatarImage src={editPhotoUrl} className="object-cover" />
                        <AvatarFallback>{editName.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="absolute -bottom-2 -right-2 flex gap-1">
                        <Button 
                          size="icon" 
                          variant="secondary" 
                          className="rounded-full w-8 h-8 shadow-md"
                          onClick={handleShufflePhoto}
                        >
                          <RefreshCw className="w-4 h-4" />
                        </Button>
                        <Button 
                          size="icon" 
                          variant="secondary" 
                          className="rounded-full w-8 h-8 shadow-md"
                          onClick={() => fileInputRef.current?.click()}
                        >
                          <Upload className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    <input 
                      type="file" 
                      ref={fileInputRef} 
                      className="hidden" 
                      accept="image/*" 
                      onChange={handleFileChange} 
                    />
                    <div className="flex flex-col items-center gap-1 text-center">
                      <p className="text-xs text-muted-foreground font-medium">Customize your profile photo</p>
                      <div className="flex gap-2">
                        <Button variant="link" size="sm" className="h-auto p-0 text-[10px]" onClick={handleShufflePhoto}>Shuffle Avatar</Button>
                        <span className="text-[10px] text-muted-foreground">•</span>
                        <Button variant="link" size="sm" className="h-auto p-0 text-[10px]" onClick={() => fileInputRef.current?.click()}>Upload from Device</Button>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name">Full Name</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input id="name" value={editName} onChange={(e) => setEditName(e.target.value)} className="pl-10 h-12 rounded-xl" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="email">Email Address</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input id="email" type="email" value={editEmail} onChange={(e) => setEditEmail(e.target.value)} className="pl-10 h-12 rounded-xl" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="phone">Phone Number</Label>
                      <div className="relative">
                        <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                        <Input id="phone" value={editPhone} onChange={(e) => setEditPhone(e.target.value)} className="pl-10 h-12 rounded-xl" />
                      </div>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button className="w-full rounded-full h-12 text-lg" onClick={handleSaveProfile} disabled={isUpdating}>
                    {isUpdating ? <Loader2 className="animate-spin w-5 h-5 mr-2" /> : <CheckCircle2 className="w-5 h-5 mr-2" />}
                    Save Changes
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>

            <Separator />

            <div className="flex items-center justify-between p-4 hover:bg-slate-50 cursor-pointer transition-colors group" onClick={handlePaymentMethods}>
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                  <CreditCard className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold">Payment Methods</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </div>
        </div>

        {/* Security Group */}
        <div className="space-y-3">
          <h3 className="px-4 text-xs font-bold text-muted-foreground uppercase tracking-widest">Security</h3>
          <div className="bg-white rounded-3xl overflow-hidden shadow-sm border">
            <Dialog>
              <DialogTrigger asChild>
                <div className="flex items-center justify-between p-4 hover:bg-slate-50 cursor-pointer transition-colors group">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                      <Lock className="w-5 h-5" />
                    </div>
                    <span className="text-sm font-bold">Change UPI PIN</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full uppercase">Secure</span>
                    <ChevronRight className="w-5 h-5 text-muted-foreground" />
                  </div>
                </div>
              </DialogTrigger>
              <DialogContent className="rounded-3xl max-w-[90vw] sm:max-w-md">
                <DialogHeader>
                  <DialogTitle>Set Security PIN</DialogTitle>
                  <DialogDescription>This PIN will be required for all transactions.</DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <Label htmlFor="pin">Enter New 4-6 Digit PIN</Label>
                    <Input id="pin" type="password" maxLength={6} placeholder="••••••" className="text-center text-2xl h-14 tracking-[0.5em] font-bold rounded-xl" value={newPin} onChange={(e) => setNewPin(e.target.value.replace(/\D/g, ''))} />
                  </div>
                  <Button className="w-full h-12 rounded-full" disabled={isUpdating} onClick={handleUpdatePin}>
                    {isUpdating ? <Loader2 className="animate-spin w-4 h-4 mr-2" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
                    Update PIN
                  </Button>
                </div>
              </DialogContent>
            </Dialog>

            <Separator />

            <div className="flex items-center justify-between p-4 hover:bg-slate-50 cursor-pointer transition-colors group">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                  <Shield className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold">Privacy Policy</span>
              </div>
              <ChevronRight className="w-5 h-5 text-muted-foreground" />
            </div>
          </div>
        </div>

        {/* Preferences */}
        <div className="space-y-3">
          <h3 className="px-4 text-xs font-bold text-muted-foreground uppercase tracking-widest">Preferences</h3>
          <div className="bg-white rounded-3xl overflow-hidden shadow-sm border">
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
                  <Bell className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold">Notifications</span>
              </div>
              <Switch defaultChecked />
            </div>
            <Separator />
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
                  <Globe className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold">Language</span>
              </div>
              <span className="text-xs text-muted-foreground">English (IN)</span>
            </div>
            <Separator />
            <div className="flex items-center justify-between p-4">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
                  <Moon className="w-5 h-5" />
                </div>
                <span className="text-sm font-bold">Dark Mode</span>
              </div>
              <Switch />
            </div>
          </div>
        </div>

        <Button variant="ghost" className="w-full h-14 rounded-2xl text-red-500 hover:text-red-600 hover:bg-red-50 font-bold" onClick={() => router.push('/')}>
          <LogOut className="w-5 h-5 mr-2" /> Log Out
        </Button>
      </div>
      
      <div className="text-center pb-8">
        <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em]">UPI-Payment v2.4.0</p>
      </div>
    </div>
  );
}
