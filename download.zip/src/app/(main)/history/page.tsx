
"use client";

import { usePayZen, type Transaction } from "@/hooks/use-pay-zen";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { 
  Search, 
  Filter, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Calendar, 
  MessageSquare, 
  X, 
  Repeat, 
  Trash2,
  MoreVertical
} from "lucide-react";
import { useState, useEffect, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useToast } from "@/hooks/use-toast";

function HistoryContent() {
  const { transactions, loading, clearTransactions, deleteTransaction } = usePayZen();
  const searchParams = useSearchParams();
  const router = useRouter();
  const { toast } = useToast();
  
  const initialQuery = searchParams.get('q') || "";
  const [searchTerm, setSearchTerm] = useState(initialQuery);

  useEffect(() => {
    const q = searchParams.get('q');
    if (q !== null) {
      setSearchTerm(q);
    }
  }, [searchParams]);

  const filteredTransactions = transactions.filter(tx => 
    tx.payeeName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tx.upiId.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (tx.note && tx.note.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const clearSearch = () => {
    setSearchTerm("");
    router.push('/history');
  };

  const handleRepeatPayment = (tx: Transaction) => {
    const params = new URLSearchParams();
    params.set('upi', tx.upiId);
    params.set('name', tx.payeeName);
    params.set('amount', tx.amount.toString());
    params.set('quick', 'true'); // Skips directly to PIN entry
    if (tx.note) params.set('note', tx.note);
    router.push(`/transfer?${params.toString()}`);
  };

  const handleClearHistory = () => {
    clearTransactions();
    toast({
      title: "History Cleared",
      description: "All transaction records have been deleted.",
    });
  };

  const handleDeleteItem = (id: string) => {
    deleteTransaction(id);
    toast({
      title: "Transaction Deleted",
      description: "The record has been removed from your history.",
    });
  };

  if (loading) return <div className="p-8 text-center">Loading transactions...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Transaction History</h1>
        <div className="flex gap-2">
          {searchTerm && (
            <Button variant="ghost" size="sm" onClick={clearSearch} className="text-muted-foreground hover:text-primary">
              <X className="w-4 h-4 mr-1" /> Clear Filter
            </Button>
          )}
          
          {transactions.length > 0 && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10 font-bold">
                  <Trash2 className="w-4 h-4 mr-1.5" /> Clear All
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent className="rounded-3xl">
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This action cannot be undone. This will permanently delete your entire transaction history from this device.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="rounded-full">Cancel</AlertDialogCancel>
                  <AlertDialogAction onClick={handleClearHistory} className="bg-destructive text-white hover:bg-destructive/90 rounded-full">
                    Delete History
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          )}
        </div>
      </div>

      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search by name, UPI ID or message..." 
            className="pl-10 rounded-xl h-12" 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <Button variant="outline" size="icon" className="rounded-xl h-12 w-12 border-border bg-white">
          <Filter className="w-5 h-5 text-muted-foreground" />
        </Button>
      </div>

      <div className="space-y-6">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-xs font-bold text-muted-foreground uppercase tracking-widest bg-background/50 sticky top-0 py-2 z-10 backdrop-blur-sm">
            <Calendar className="w-3 h-3" /> {searchTerm ? `Results for "${searchTerm}"` : 'Latest Activity'}
          </div>
          {filteredTransactions.length > 0 ? (
            filteredTransactions.map((tx) => (
              <div key={tx.id} className="bg-white p-5 rounded-2xl flex flex-col gap-3 shadow-sm border border-transparent hover:border-primary/20 transition-all">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                      tx.type === 'receive' ? 'bg-green-50 text-green-600' : 
                      tx.type === 'topup' ? 'bg-blue-50 text-primary' : 
                      'bg-red-50 text-red-600'
                    }`}>
                      {tx.type === 'receive' ? <ArrowDownLeft className="w-6 h-6" /> : 
                       tx.type === 'topup' ? <ArrowDownLeft className="w-6 h-6" /> :
                       <ArrowUpRight className="w-6 h-6" />}
                    </div>
                    <div>
                      <p className="font-bold text-base hover:text-primary cursor-pointer transition-colors" onClick={() => setSearchTerm(tx.payeeName)}>{tx.payeeName}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(tx.timestamp).toLocaleString('en-IN', { 
                          month: 'short', 
                          day: 'numeric', 
                          hour: '2-digit', 
                          minute: '2-digit' 
                        })}
                      </p>
                    </div>
                  </div>
                  <div className="text-right flex items-center gap-4">
                    <div className="flex flex-col items-end gap-1">
                      <p className={`font-bold text-lg ${tx.type === 'receive' || tx.type === 'topup' ? 'text-green-600' : 'text-foreground'}`}>
                        {tx.type === 'receive' || tx.type === 'topup' ? '+' : '-'} ₹{tx.amount.toLocaleString('en-IN')}
                      </p>
                      <span className={`text-[9px] px-2 py-0.5 rounded-full font-bold uppercase ${
                        tx.status === 'completed' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'
                      }`}>
                        {tx.status}
                      </span>
                    </div>
                    
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="rounded-full h-8 w-8 text-muted-foreground">
                          <MoreVertical className="w-4 h-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="rounded-xl border-none shadow-xl ring-1 ring-black/5">
                        <DropdownMenuItem onClick={() => handleRepeatPayment(tx)} className="text-xs font-bold gap-2 p-2.5 rounded-lg cursor-pointer">
                          <Repeat className="w-3.5 h-3.5 text-primary" /> Repeat Payment
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleDeleteItem(tx.id)} className="text-xs font-bold gap-2 p-2.5 rounded-lg cursor-pointer text-destructive focus:bg-destructive/10 focus:text-destructive">
                          <Trash2 className="w-3.5 h-3.5" /> Delete Record
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </div>
                
                <div className="flex flex-col gap-2 pl-16">
                   <div className="flex items-center justify-between gap-4">
                     <div className="flex flex-col gap-0.5">
                       <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">UPI ID / Reference</p>
                       <p className="text-xs font-mono text-foreground">{tx.upiId}</p>
                     </div>
                     <Button 
                       variant="outline" 
                       size="sm" 
                       onClick={() => handleRepeatPayment(tx)}
                       className="rounded-full h-8 text-xs border-primary text-primary hover:bg-primary/5 font-bold"
                     >
                       <Repeat className="w-3 h-3 mr-1.5" /> Repeat
                     </Button>
                   </div>
                   
                   {tx.note && (
                     <div className="flex flex-col gap-1">
                        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-wider">Message</p>
                        <div className="flex items-start gap-2 py-2 px-3 bg-slate-50 rounded-xl border border-slate-100 w-full">
                          <MessageSquare className="w-3.5 h-3.5 text-primary mt-0.5 shrink-0" />
                          <p className="text-sm italic text-muted-foreground leading-relaxed">{tx.note}</p>
                        </div>
                     </div>
                   )}
                </div>
              </div>
            ))
          ) : (
            <div className="py-20 text-center space-y-2">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400">
                <Search className="w-8 h-8" />
              </div>
              <p className="text-muted-foreground">No transactions found.</p>
              {searchTerm && (
                <Button variant="link" onClick={clearSearch} className="text-primary font-bold">
                  Show all transactions
                </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function HistoryPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center">Loading...</div>}>
      <HistoryContent />
    </Suspense>
  );
}
