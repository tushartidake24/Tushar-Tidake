"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { validateQrCodePayment, QrCodePaymentValidationOutput } from "@/ai/flows/qr-code-payment-validation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  ArrowLeft, 
  ScanLine, 
  Loader2, 
  AlertCircle, 
  CheckCircle2, 
  ArrowRight, 
  Camera, 
  Upload,
  Sparkles,
  RefreshCw,
  Info
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function ScanPage() {
  const [isValidating, setIsValidating] = useState(false);
  const [result, setResult] = useState<QrCodePaymentValidationOutput | null>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('environment');
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const router = useRouter();
  
  useEffect(() => {
    let currentStream: MediaStream | null = null;

    const getCameraPermission = async () => {
      try {
        if (videoRef.current && videoRef.current.srcObject) {
          const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
          tracks.forEach(track => track.stop());
        }

        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: facingMode } 
        });

        currentStream = stream;
        setHasCameraPermission(true);

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing camera:', error);
        setHasCameraPermission(false);
      }
    };

    getCameraPermission();

    return () => {
      if (currentStream) {
        currentStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [facingMode]);

  const toggleCamera = () => {
    setFacingMode(prev => prev === 'user' ? 'environment' : 'user');
  };

  const handleScan = async (sourceDataUri?: string) => {
    let dataUri = sourceDataUri;

    // If no URI provided, capture from video stream
    if (!dataUri && videoRef.current) {
      const canvas = document.createElement('canvas');
      canvas.width = videoRef.current.videoWidth;
      canvas.height = videoRef.current.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(videoRef.current, 0, 0);
        dataUri = canvas.toDataURL('image/jpeg', 0.8);
      }
    }

    if (!dataUri) {
      toast({ variant: "destructive", title: "Input Required", description: "Could not capture image." });
      return;
    }

    setIsValidating(true);
    setResult(null);

    try {
      const output = await validateQrCodePayment({ photoDataUri: dataUri });
      setResult(output);
      
      if (output.isValidUpiQr) {
        toast({
          title: "Scan Successful",
          description: `Identified: ${output.payeeName || 'Verified Recipient'}`
        });
      } else {
        toast({
          variant: "destructive",
          title: "Scan Failed",
          description: output.validationMessage
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "AI Error",
        description: "Failed to analyze the image. Please try again."
      });
    } finally {
      setIsValidating(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const dataUri = event.target?.result as string;
        handleScan(dataUri);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleProceed = () => {
    if (result?.isValidUpiQr && result.upiId) {
      const params = new URLSearchParams();
      params.set('upi', result.upiId);
      if (result.payeeName) params.set('name', result.payeeName);
      router.push(`/transfer?${params.toString()}`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()} className="rounded-full">
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-2xl font-bold">Scan & Pay</h1>
        </div>
        <Button 
          variant="outline" 
          size="icon" 
          onClick={toggleCamera} 
          className="rounded-full bg-white shadow-sm"
        >
          <RefreshCw className="w-5 h-5 text-primary" />
        </Button>
      </div>

      <div className="relative aspect-square w-full max-w-sm mx-auto bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border-4 border-white/10">
        <video 
          ref={videoRef} 
          className="w-full h-full object-cover" 
          autoPlay 
          muted 
          playsInline
        />
        
        {hasCameraPermission === false && (
          <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center bg-slate-900/90 text-white z-20">
            <Alert variant="destructive" className="bg-destructive/20 border-destructive text-white mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Camera Access Required</AlertTitle>
              <AlertDescription>
                Please allow camera access to use this feature.
              </AlertDescription>
            </Alert>
            <Button variant="outline" className="text-white border-white/20 hover:bg-white/10 rounded-full" onClick={() => window.location.reload()}>
              Retry Permission
            </Button>
          </div>
        )}

        <div className="absolute inset-0 pointer-events-none z-10 flex items-center justify-center">
          <div className="w-64 h-64 border-2 border-primary/50 rounded-3xl relative">
            <div className="absolute -top-1 -left-1 w-8 h-8 border-t-4 border-l-4 border-primary rounded-tl-xl"></div>
            <div className="absolute -top-1 -right-1 w-8 h-8 border-t-4 border-r-4 border-primary rounded-tr-xl"></div>
            <div className="absolute -bottom-1 -left-1 w-8 h-8 border-b-4 border-l-4 border-primary rounded-bl-xl"></div>
            <div className="absolute -bottom-1 -right-1 w-8 h-8 border-b-4 border-r-4 border-primary rounded-br-xl"></div>
            
            <div className="absolute top-0 left-0 right-0 h-0.5 bg-primary/80 shadow-[0_0_15px_rgba(63,81,181,1)] animate-[scan_2s_ease-in-out_infinite]"></div>
          </div>
        </div>

        {isValidating && (
          <div className="absolute inset-0 bg-primary/20 backdrop-blur-sm flex flex-col items-center justify-center z-30 animate-in fade-in">
             <Loader2 className="w-12 h-12 text-white animate-spin mb-2" />
             <p className="text-white font-bold text-sm tracking-widest uppercase">AI Analyzing...</p>
          </div>
        )}
      </div>

      <div className="flex gap-3 justify-center">
        <Button 
          onClick={() => handleScan()} 
          disabled={hasCameraPermission === false || isValidating}
          size="lg"
          className="rounded-full h-14 px-10 bg-primary hover:bg-primary/90 shadow-lg text-lg"
        >
          <Camera className="w-5 h-5 mr-2" /> Tap to Scan
        </Button>
        
        <input 
          type="file" 
          ref={fileInputRef} 
          className="hidden" 
          accept="image/*" 
          onChange={handleFileUpload}
        />
        
        <Button 
          variant="outline" 
          className="rounded-full h-14 w-14 border-slate-200 bg-white shadow-md" 
          onClick={() => fileInputRef.current?.click()}
          disabled={isValidating}
        >
          <Upload className="w-6 h-6 text-primary" />
        </Button>
      </div>

      {!result && !isValidating && (
        <div className="bg-slate-50 p-4 rounded-2xl border flex gap-3">
          <Info className="w-5 h-5 text-primary shrink-0 mt-0.5" />
          <p className="text-xs text-muted-foreground">
            Our Vision AI will detect the UPI QR code directly from the video stream or your uploaded photo.
          </p>
        </div>
      )}

      {result && (
        <Card className={`border-none shadow-xl animate-in slide-in-from-bottom-4 duration-500 ${result.isValidUpiQr ? 'bg-green-50' : 'bg-red-50'}`}>
          <CardContent className="p-6">
            <div className="flex items-start gap-4">
              <div className={`mt-1 p-2.5 rounded-2xl ${result.isValidUpiQr ? 'bg-green-200 text-green-700' : 'bg-red-200 text-red-700'}`}>
                {result.isValidUpiQr ? <CheckCircle2 className="w-6 h-6" /> : <AlertCircle className="w-6 h-6" />}
              </div>
              <div className="flex-1 space-y-2">
                <div>
                  <h4 className={`font-bold text-lg ${result.isValidUpiQr ? 'text-green-800' : 'text-red-800'}`}>
                    {result.isValidUpiQr ? 'Verified Merchant' : 'Scan Error'}
                  </h4>
                  <p className="text-xs text-muted-foreground leading-tight">{result.validationMessage}</p>
                </div>
                
                {result.isValidUpiQr && (
                  <div className="pt-3 border-t border-green-200/50 space-y-3">
                    <div>
                      <p className="text-[10px] font-bold text-green-700 uppercase tracking-widest">Recipient</p>
                      <p className="font-bold text-xl text-green-900">{result.payeeName || 'Unknown Name'}</p>
                      <p className="text-sm font-mono text-green-800">{result.upiId}</p>
                    </div>
                    <Button 
                      onClick={handleProceed}
                      className="w-full h-14 bg-green-600 hover:bg-green-700 text-white rounded-full flex items-center justify-center gap-2 text-lg shadow-lg"
                    >
                      Proceed to Pay <ArrowRight className="w-5 h-5" />
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <style jsx global>{`
        @keyframes scan {
          0%, 100% { top: 0; }
          50% { top: 100%; }
        }
      `}</style>
    </div>
  );
}
