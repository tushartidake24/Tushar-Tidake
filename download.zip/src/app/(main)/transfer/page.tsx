
"use client";

import { useState, useEffect, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { usePayZen } from "@/hooks/use-pay-zen";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ArrowLeft, 
  Send, 
  CheckCircle2, 
  IndianRupee, 
  History, 
  MessageSquare, 
  ShieldCheck,
  Loader2,
  Edit2,
  Gift,
  AlertCircle
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

type TransferStep = 'details' | 'pin' | 'success';

const QUICK_AMOUNTS = [100, 500, 1000, 2000];

function TransferContent() {
  const searchParams = useSearchParams();
  const initialTab = (searchParams.get('tab') as "upi" | "phone" | "bank") || "upi";
  
  const [recipientType, setRecipientType] = useState<"upi" | "phone" | "bank">(initialTab);
  const [upiId, setUpiId] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [ifsc, setIfsc] = useState("");
  const [amount, setAmount] = useState("");
  const [payeeName, setPayeeName] = useState("");
  const [note, setNote] = useState("");
  const [pinInput, setPinInput] = useState("");
  const [step, setStep] = useState<TransferStep>('details');
  const [isProcessing, setIsProcessing] = useState(false);
  const [isEditingAmount, setIsEditingAmount] = useState(false);
  
  const { balance, sendMoney, verifyPin } = usePayZen();
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    const tab = searchParams.get('tab') as "upi" | "phone" | "bank";
    if (tab) setRecipientType(tab);
    
    const upi = searchParams.get('upi');
    if (upi) setUpiId(upi);
    
    const name = searchParams.get('name');
    if (name) setPayeeName(name);

    const amt = searchParams.get('amount');
    if (amt) setAmount(amt);

    const msg = searchParams.get('note');
    if (msg) setNote(msg);

    const isQuick = searchParams.get('quick') === 'true';
    if (isQuick && amt) {
      setStep('pin');
    }
  }, [searchParams]);

  const handleInitiateTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    
    if (isNaN(val) || val <= 0) {
      toast({ variant: "destructive", title: "Invalid amount" });
      return;
    }
    
    if (val > balance) {
      toast({ variant: "destructive", title: "Insufficient balance" });
      return;
    }

    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setStep('pin');
    }, 1000);
  };

  const handleVerifyPIN = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!verifyPin(pinInput)) {
      toast({ 
        variant: "destructive", 
        title: "Transaction Failed", 
        description: "Incorrect Security PIN. Please try again." 
      });
      setPinInput("");
      return;
    }

    setIsProcessing(true);
    
    setTimeout(() => {
      let recipient = "";
      if (recipientType === 'upi') recipient = upiId;
      else if (recipientType === 'phone') recipient = `${phoneNumber}@upipay`;
      else recipient = `${accountNumber}@${ifsc}`;

      const name = payeeName || (recipientType === 'phone' ? `User ${phoneNumber.slice(-4)}` : recipient.split('@')[0]);
      
      const success = sendMoney(parseFloat(amount), name, recipient, note);
      setIsProcessing(false);
      if (success) {
        setStep('success');
      }
    }, 2000);
  };

  if (step === 'success') {
    return (
      <div className="flex flex-col items-center justify-center h-[70vh] space-y-6 text-center animate-in fade-in zoom-in">
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center text-green-600">
          <CheckCircle2 className="w-16 h-16" />
        </div>
        <div className="space-y-2">
          <h2 className="text-3xl font-bold">Payment Successful</h2>
          <p className="text-muted-foreground text-lg">
            ₹{parseFloat(amount).toLocaleString('en-IN')} sent to {payeeName || upiId || 'Recipient'}
          </p>
          <div className="flex items-center justify-center gap-2 text-indigo-600 bg-indigo-50 py-3 px-6 rounded-2xl mt-4 border border-indigo-100 animate-bounce">
            <Gift className="w-5 h-5" />
            <span className="font-bold">You earned a Scratch Card!</span>
          </div>
        </div>
        <div className="flex flex-col w-full max-w-xs gap-3">
          <Button 
            onClick={() => router.push('/dashboard')}
            className="bg-primary rounded-full h-12 text-lg"
          >
            Go Claim Reward
          </Button>
          <Button 
            variant="outline"
            onClick={() => router.push('/history')}
            className="rounded-full h-12 text-lg border-primary text-primary"
          >
            <History className="w-4 h-4 mr-2" /> View History
          </Button>
        </div>
      </div>
    );
  }

  if (step === 'pin') {
    return (
      <div className="space-y-6 max-w-md mx-auto">
        <div className="flex items-center gap-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => isEditingAmount ? setIsEditingAmount(false) : setStep('details')} 
            className="rounded-full"
          >
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-2xl font-bold">{isEditingAmount ? 'Edit Amount' : 'Verify Payment'}</h1>
        </div>

        <Card className="border-none shadow-xl overflow-hidden">
          <CardContent className="p-6 pt-10 space-y-6">
            <div className="bg-slate-50 p-6 rounded-2xl border border-dashed border-primary/20 text-center space-y-4">
              {!isEditingAmount ? (
                <>
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">
                    Sending to {payeeName || upiId || 'Recipient'}
                  </p>
                  <div className="flex items-center justify-center gap-3">
                    <h2 className="text-4xl font-bold text-primary">₹{parseFloat(amount).toLocaleString('en-IN', { minimumFractionDigits: 2 })}</h2>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => setIsEditingAmount(true)}
                      className="w-8 h-8 text-muted-foreground hover:text-primary rounded-full"
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                  </div>
                </>
              ) : (
                <div className="space-y-4 animate-in fade-in zoom-in">
                  <div className="relative">
                    <IndianRupee className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                    <Input
                      type="number"
                      placeholder="0.00"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      className="h-16 rounded-xl pl-12 text-2xl font-bold border-2 focus:border-primary text-center"
                      autoFocus
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1 rounded-full h-12" onClick={() => setIsEditingAmount(false)}>Cancel</Button>
                    <Button className="flex-1 rounded-full h-12" onClick={() => setIsEditingAmount(false)}>Done</Button>
                  </div>
                </div>
              )}
            </div>

            {!isEditingAmount && (
              <form onSubmit={handleVerifyPIN} className="space-y-6 text-center animate-in slide-in-from-bottom-2">
                <div className="space-y-2">
                  <Label className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Enter UPI PIN</Label>
                  <div className="flex justify-center">
                    <input
                      type="password"
                      maxLength={6}
                      placeholder="••••••"
                      value={pinInput}
                      onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
                      className="text-center text-3xl h-16 w-48 tracking-[0.5em] font-bold rounded-xl border-2 border-input focus:border-primary outline-none bg-white shadow-inner"
                      required
                      autoFocus
                    />
                  </div>
                  <p className="text-[10px] text-muted-foreground flex items-center justify-center gap-1">
                    <ShieldCheck className="w-3 h-3" /> Secure 256-bit encryption active
                  </p>
                </div>
                
                <Button
                  type="submit"
                  disabled={isProcessing}
                  className="w-full h-14 rounded-full text-lg bg-primary hover:bg-primary/90 shadow-lg"
                >
                  {isProcessing ? (
                    <div className="flex items-center gap-2">
                      <Loader2 className="w-5 h-5 animate-spin" /> Verifying...
                    </div>
                  ) : (
                    "Confirm Payment"
                  )}
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="rounded-full">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <h1 className="text-2xl font-bold">Transfer Money</h1>
      </div>

      <Card className="border-none shadow-lg overflow-hidden">
        <Tabs value={recipientType} onValueChange={(val) => setRecipientType(val as "upi" | "phone" | "bank")}>
          <TabsList className="w-full h-14 rounded-none bg-slate-50 border-b">
            <TabsTrigger value="upi" className="flex-1 h-full rounded-none font-bold">UPI ID</TabsTrigger>
            <TabsTrigger value="phone" className="flex-1 h-full rounded-none font-bold">Phone</TabsTrigger>
            <TabsTrigger value="bank" className="flex-1 h-full rounded-none font-bold">Bank</TabsTrigger>
          </TabsList>

          <CardContent className="p-6">
            <form onSubmit={handleInitiateTransfer} className="space-y-6">
              <TabsContent value="upi" className="mt-0">
                <div className="space-y-2">
                  <Label htmlFor="upi">Recipient UPI ID</Label>
                  <Input id="upi" placeholder="name@upi" value={upiId} onChange={(e) => setUpiId(e.target.value)} required={recipientType === 'upi'} className="h-14 rounded-xl text-lg" />
                </div>
              </TabsContent>

              <TabsContent value="phone" className="mt-0">
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input id="phone" type="tel" placeholder="10-digit number" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, '').slice(0, 10))} required={recipientType === 'phone'} className="h-14 rounded-xl text-lg" />
                </div>
              </TabsContent>

              <TabsContent value="bank" className="mt-0">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="account">Account Number</Label>
                    <Input id="account" placeholder="Bank account number" value={accountNumber} onChange={(e) => setAccountNumber(e.target.value.replace(/\D/g, ''))} required={recipientType === 'bank'} className="h-14 rounded-xl text-lg" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="ifsc">IFSC Code</Label>
                    <Input id="ifsc" placeholder="SBIN0001234" value={ifsc} onChange={(e) => setIfsc(e.target.value.toUpperCase())} required={recipientType === 'bank'} className="h-14 rounded-xl text-lg" />
                  </div>
                </div>
              </TabsContent>

              <div className="space-y-3">
                <Label htmlFor="amount">Amount (₹)</Label>
                <div className="relative">
                  <IndianRupee className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input id="amount" type="number" placeholder="0.00" value={amount} onChange={(e) => setAmount(e.target.value)} required className="h-16 rounded-xl pl-12 text-2xl font-bold border-2 focus:border-primary" />
                </div>
                <div className="flex flex-wrap gap-2">
                  {QUICK_AMOUNTS.map(amt => (
                    <Button key={amt} type="button" variant="outline" size="sm" onClick={() => setAmount(amt.toString())} className="rounded-full border-primary/20 hover:border-primary text-xs font-bold">+₹{amt}</Button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="note">Add a Message</Label>
                <Input id="note" placeholder="What's this for?" value={note} onChange={(e) => setNote(e.target.value)} className="h-14 rounded-xl" />
              </div>

              <Button type="submit" disabled={isProcessing} className="w-full h-14 rounded-full text-lg bg-primary hover:bg-primary/90 mt-4 shadow-lg">
                {isProcessing ? <Loader2 className="w-5 h-5 animate-spin" /> : <span className="flex items-center gap-2">Send Securely <Send className="w-4 h-4" /></span>}
              </Button>
            </form>
          </CardContent>
        </Tabs>
      </Card>
      
      <div className="bg-indigo-50 p-6 rounded-2xl border border-indigo-100 flex items-start gap-4">
        <Gift className="w-6 h-6 text-indigo-600 shrink-0 mt-1" />
        <div className="space-y-1">
          <h4 className="font-bold text-sm text-indigo-900">Earn Cashback Rewards</h4>
          <p className="text-xs text-indigo-700 leading-relaxed">
            Get a scratch card with every transaction! Scratch cards reward you with random cashback between ₹1 and ₹50 added directly to your account.
          </p>
        </div>
      </div>
    </div>
  );
}

export default function TransferPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center">Loading...</div>}>
      <TransferContent />
    </Suspense>
  );
}
