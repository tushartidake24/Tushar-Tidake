
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  ArrowLeft, 
  Zap, 
  Flame, 
  Droplets, 
  Tv, 
  Wifi, 
  ShieldCheck,
  ChevronRight,
  Info
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const BILL_CATEGORIES = [
  { icon: Zap, label: "Electricity", color: "text-yellow-600 bg-yellow-50", description: "Pay power bills" },
  { icon: Droplets, label: "Water", color: "text-blue-600 bg-blue-50", description: "Water board bills" },
  { icon: Flame, label: "Gas", color: "text-orange-600 bg-orange-50", description: "Gas connections" },
  { icon: Tv, label: "DTH", color: "text-purple-600 bg-purple-50", description: "TV subscription" },
  { icon: Wifi, label: "Broadband", color: "text-cyan-600 bg-cyan-50", description: "Home internet" },
];

export default function BillsPage() {
  const router = useRouter();
  const { toast } = useToast();

  const handleCategoryClick = (label: string) => {
    toast({
      title: `${label} Service`,
      description: `Searching for active billers in your region for ${label.toLowerCase()}...`,
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => router.back()} className="rounded-full">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <h1 className="text-2xl font-bold">Pay Bills</h1>
      </div>

      <div className="bg-primary p-6 rounded-3xl text-white space-y-4 relative overflow-hidden">
        <div className="relative z-10">
          <p className="text-sm text-white/70 uppercase font-bold tracking-widest">Pending Bills</p>
          <h2 className="text-2xl font-bold">₹1,245.00</h2>
          <p className="text-xs text-white/60">2 bills due this month</p>
          <Button variant="secondary" className="mt-4 bg-white text-primary rounded-full hover:bg-white/90">
            Pay All Due
          </Button>
        </div>
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <ShieldCheck className="w-24 h-24" />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-3">
        {BILL_CATEGORIES.map((cat, i) => (
          <div 
            key={i} 
            onClick={() => handleCategoryClick(cat.label)}
            className="bg-white p-4 rounded-2xl flex items-center justify-between shadow-sm hover:shadow-md transition-all cursor-pointer group border border-transparent hover:border-primary/20"
          >
            <div className="flex items-center gap-4">
              <div className={`w-12 h-12 rounded-2xl flex items-center justify-center ${cat.color}`}>
                <cat.icon className="w-6 h-6" />
              </div>
              <div>
                <p className="font-bold text-sm group-hover:text-primary transition-colors">{cat.label}</p>
                <p className="text-[10px] text-muted-foreground uppercase tracking-wider">{cat.description}</p>
              </div>
            </div>
            <ChevronRight className="w-5 h-5 text-muted-foreground" />
          </div>
        ))}
      </div>

      <div className="bg-slate-50 p-4 rounded-2xl flex gap-3 border border-slate-100">
        <Info className="w-5 h-5 text-primary shrink-0 mt-0.5" />
        <p className="text-xs text-muted-foreground leading-relaxed">
          UPI-Payment supports over 2,000 billers across India through the Bharat Bill Payment System (BBPS). All payments are instant and safe.
        </p>
      </div>
    </div>
  );
}
