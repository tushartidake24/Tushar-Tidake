
"use client";

import { useState } from "react";
import { usePayZen, type Transaction } from "@/hooks/use-pay-zen";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  ScanLine, 
  Wallet, 
  Bell, 
  ChevronRight, 
  MoreHorizontal, 
  Trash2,
  Eye, 
  EyeOff, 
  Smartphone, 
  Landmark, 
  Receipt, 
  Settings,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Repeat,
  PlusCircle,
  Loader2,
  Gift,
  Sparkles
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function Dashboard() {
  const { balance, transactions, loading, pin, profile, rewardsCount, claimReward, deleteTransaction } = usePayZen();
  const { toast } = useToast();
  const router = useRouter();
  const [showBalance, setShowBalance] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isScratching, setIsScratching] = useState(false);
  const [scratchedAmount, setScratchedAmount] = useState<number | null>(null);
  const [isRewardDialogOpen, setIsRewardDialogOpen] = useState(false);

  const isDefaultPin = pin === "1234";

  if (loading) {
    return <div className="flex items-center justify-center h-[50vh]">Loading wallet...</div>;
  }

  const handleScratch = () => {
    if (isScratching || rewardsCount <= 0) return;
    
    setIsScratching(true);
    // Random reward between ₹1 and ₹50
    const reward = Math.floor(Math.random() * 50) + 1;
    
    setTimeout(() => {
      setScratchedAmount(reward);
      claimReward(reward);
      setIsScratching(false);
      toast({
        title: "Cashback Won!",
        description: `₹${reward} has been added to your wallet.`,
      });
    }, 1500);
  };

  const handleRepeatPayment = (tx: Transaction) => {
    const params = new URLSearchParams();
    params.set('upi', tx.upiId);
    params.set('name', tx.payeeName);
    params.set('amount', tx.amount.toString());
    params.set('quick', 'true');
    if (tx.note) params.set('note', tx.note);
    router.push(`/transfer?${params.toString()}`);
  };

  const handleDeleteTransaction = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    deleteTransaction(id);
    toast({
      title: "Transaction Deleted",
      description: "Record removed from dashboard.",
    });
  };

  const quickActions = [
    { icon: ArrowUpRight, label: "Send", href: "/transfer", color: "bg-blue-100 text-primary" },
    { icon: ScanLine, label: "Scan", href: "/scan", color: "bg-orange-100 text-accent" },
    { icon: ArrowDownLeft, label: "Request", href: "/request", color: "bg-green-100 text-green-600" },
  ];

  const moreOptions = [
    { icon: Lock, label: "Security PIN", description: "Set or reset your transaction PIN", href: "/settings" },
    { icon: Smartphone, label: "Mobile Recharge", description: "Top up your phone instantly", href: "/recharge" },
    { icon: Landmark, label: "Bank Transfer", description: "Transfer to any bank account", href: "/transfer?tab=bank" },
    { icon: Receipt, label: "Pay Bills", description: "Electricity, Water, Gas & more", href: "/bills" },
    { icon: Settings, label: "Settings", description: "Manage your profile and privacy", href: "/settings" },
  ];

  const displayedTransactions = isExpanded ? transactions.slice(0, 15) : transactions.slice(0, 5);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Avatar className="w-12 h-12 border-2 border-primary cursor-pointer" onClick={() => router.push('/settings')}>
            <AvatarImage src={profile.photoUrl} />
            <AvatarFallback>{profile.name.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="hidden sm:block">
            <p className="text-xs text-muted-foreground">Welcome back,</p>
            <p className="text-sm font-bold">{profile.name}</p>
          </div>
        </div>
        
        <Popover>
          <PopoverTrigger asChild>
            <Button variant="ghost" size="icon" className="rounded-full bg-white shadow-sm border relative">
              <Bell className="w-5 h-5 text-muted-foreground" />
              <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-accent rounded-full border-2 border-white"></span>
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-80 p-0 overflow-hidden" align="end">
            <div className="p-4 bg-primary text-white">
              <h4 className="font-bold">Notifications</h4>
            </div>
            <div className="p-8 text-center text-muted-foreground text-sm">
              No new notifications
            </div>
          </PopoverContent>
        </Popover>
      </div>

      {/* Rewards Banner if any */}
      {rewardsCount > 0 && (
        <Card className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-none shadow-lg overflow-hidden cursor-pointer" onClick={() => { setScratchedAmount(null); setIsRewardDialogOpen(true); }}>
          <CardContent className="p-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <Gift className="w-6 h-6" />
              </div>
              <div>
                <p className="font-bold text-sm">You have {rewardsCount} Scratch Card{rewardsCount > 1 ? 's' : ''}!</p>
                <p className="text-[10px] text-white/70 uppercase tracking-widest">Tap to win cashback</p>
              </div>
            </div>
            <Sparkles className="w-5 h-5 text-yellow-300 animate-pulse" />
          </CardContent>
        </Card>
      )}

      {/* Security Warning if using default PIN */}
      {isDefaultPin && (
        <Link href="/settings">
          <div className="bg-amber-50 border border-amber-200 p-3 rounded-2xl flex items-center gap-3 text-amber-800 animate-pulse">
            <ShieldAlert className="w-5 h-5 shrink-0" />
            <div className="flex-1">
              <p className="text-[10px] font-bold uppercase tracking-wider">Security Recommendation</p>
              <p className="text-xs font-medium">You are using a default PIN. Change it now for better security.</p>
            </div>
            <ChevronRight className="w-4 h-4" />
          </div>
        </Link>
      )}

      {/* Wallet Card */}
      <Card className="bg-primary text-white border-none shadow-xl overflow-hidden relative">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <Wallet className="w-32 h-32" />
        </div>
        <CardContent className="p-8 space-y-6 relative z-10">
          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <p className="text-sm font-medium text-white/80 uppercase tracking-wider">Total Balance</p>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="h-6 w-6 text-white/80 hover:text-white hover:bg-white/10"
                  onClick={() => setShowBalance(!showBalance)}
                >
                  {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
              <Badge variant="secondary" className="bg-white/20 text-white border-none py-1 px-2 text-[10px]">
                Active
              </Badge>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold">
                {showBalance 
                  ? `₹${balance.toLocaleString('en-IN', { minimumFractionDigits: 2 })}` 
                  : "₹ ••••••••"
                }
              </span>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="bg-white/20 text-white border-none py-1.5 px-3">
              <ShieldCheck className="w-3 h-3 mr-1" /> Verified
            </Badge>
            <p className="text-xs text-white/60">{profile.upiId}</p>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-4 gap-4">
        {quickActions.map((action, i) => (
          <Link key={i} href={action.href} className="flex flex-col items-center space-y-2 group">
             <div className={`w-14 h-14 ${action.color} rounded-2xl flex items-center justify-center shadow-sm transition-transform group-hover:scale-105`}>
                <action.icon className="w-6 h-6" />
              </div>
              <span className="text-xs font-semibold">{action.label}</span>
          </Link>
        ))}
        
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex flex-col items-center space-y-2 group">
              <div className="w-14 h-14 bg-purple-100 text-purple-600 rounded-2xl flex items-center justify-center shadow-sm transition-transform group-hover:scale-105">
                <MoreHorizontal className="w-6 h-6" />
              </div>
              <span className="text-xs font-semibold">More</span>
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-64 p-2 rounded-2xl shadow-xl border-none ring-1 ring-black/5">
            <DropdownMenuLabel className="px-3 py-2 text-xs font-bold text-muted-foreground uppercase tracking-widest">
              More Services
            </DropdownMenuLabel>
            <DropdownMenuSeparator />
            {moreOptions.map((option, idx) => (
              <DropdownMenuItem 
                key={idx} 
                className="p-3 rounded-xl cursor-pointer focus:bg-primary/5"
                onClick={() => router.push(option.href)}
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center shrink-0">
                    <option.icon className="w-4 h-4 text-primary" />
                  </div>
                  <div className="space-y-0.5">
                    <p className="text-sm font-bold">{option.label}</p>
                    <p className="text-[10px] text-muted-foreground leading-tight">{option.description}</p>
                  </div>
                </div>
              </DropdownMenuItem>
            ))}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-lg">Recent Transactions</h3>
          <Button 
            variant="ghost" 
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-xs font-bold text-primary flex items-center hover:underline p-0 h-auto"
          >
            {isExpanded ? "Show Less" : "See All"} 
            <ChevronRight className={cn("w-4 h-4 transition-transform", isExpanded && "rotate-90")} />
          </Button>
        </div>
        <div className="space-y-3">
          {displayedTransactions.map((tx) => (
            <div 
              key={tx.id} 
              onClick={() => tx.type !== 'topup' && tx.type !== 'reward' && handleRepeatPayment(tx)}
              className={cn(
                "bg-white p-4 rounded-2xl flex items-center justify-between shadow-sm border border-transparent hover:border-primary/20 transition-all cursor-pointer group",
                (tx.type === 'topup' || tx.type === 'reward') && "cursor-default border-primary/5 bg-primary/5"
              )}
            >
              <div className="flex items-center gap-3">
                <div className={cn(
                  "w-10 h-10 rounded-full flex items-center justify-center",
                  tx.type === 'receive' || tx.type === 'reward' ? 'bg-green-100 text-green-600' : 
                  tx.type === 'topup' ? 'bg-blue-100 text-primary' : 
                  'bg-red-100 text-red-600'
                )}>
                  {tx.type === 'receive' || tx.type === 'reward' ? <ArrowDownLeft className="w-5 h-5" /> : 
                   tx.type === 'topup' ? <PlusCircle className="w-5 h-5" /> : 
                   <ArrowUpRight className="w-5 h-5" />}
                </div>
                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <p className="font-bold text-sm group-hover:text-primary transition-colors">{tx.payeeName}</p>
                    {tx.type === 'send' && <Repeat className="w-3 h-3 text-muted-foreground/40" />}
                  </div>
                  <p className="text-[10px] text-muted-foreground font-mono">{tx.upiId}</p>
                </div>
              </div>
              <div className="text-right flex items-center gap-4">
                <div>
                  <p className={cn(
                    "font-bold text-sm",
                    (tx.type === 'receive' || tx.type === 'topup' || tx.type === 'reward') ? 'text-green-600' : 'text-foreground'
                  )}>
                    {(tx.type === 'receive' || tx.type === 'topup' || tx.type === 'reward') ? '+' : '-'} ₹{tx.amount.toLocaleString('en-IN')}
                  </p>
                  <p className="text-[9px] text-muted-foreground uppercase font-bold">{tx.status}</p>
                </div>
                {isExpanded && tx.type !== 'reward' && (
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                    onClick={(e) => handleDeleteTransaction(tx.id, e)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scratch Card Dialog */}
      <Dialog open={isRewardDialogOpen} onOpenChange={setIsRewardDialogOpen}>
        <DialogContent className="rounded-3xl max-w-[90vw] sm:max-w-md bg-slate-50">
          <DialogHeader>
            <DialogTitle className="text-center">Scratch & Win!</DialogTitle>
            <DialogDescription className="text-center">You have earned a reward for your transaction.</DialogDescription>
          </DialogHeader>
          <div className="py-8 flex flex-col items-center gap-6">
            {!scratchedAmount ? (
              <div 
                onClick={handleScratch}
                className={cn(
                  "w-64 h-64 bg-indigo-500 rounded-3xl shadow-2xl flex flex-col items-center justify-center text-white cursor-pointer relative overflow-hidden group transition-all hover:scale-105 active:scale-95",
                  isScratching && "animate-pulse"
                )}
              >
                <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                {isScratching ? (
                  <Loader2 className="w-12 h-12 animate-spin" />
                ) : (
                  <>
                    <Gift className="w-20 h-20 mb-4" />
                    <p className="font-bold text-lg uppercase tracking-widest">Scratch Here</p>
                  </>
                )}
              </div>
            ) : (
              <div className="flex flex-col items-center animate-in zoom-in duration-500">
                <div className="w-64 h-64 bg-white rounded-3xl shadow-xl flex flex-col items-center justify-center border-4 border-yellow-400">
                  <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 mb-4">
                    <Sparkles className="w-12 h-12" />
                  </div>
                  <h2 className="text-4xl font-black text-primary">₹{scratchedAmount}</h2>
                  <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest mt-2">Cashback Won!</p>
                </div>
                <Button className="mt-8 rounded-full h-12 px-8" onClick={() => setIsRewardDialogOpen(false)}>Collect Reward</Button>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
