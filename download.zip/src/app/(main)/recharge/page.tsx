
"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { 
  ArrowLeft, 
  Smartphone, 
  Search,
  CheckCircle2,
  Zap,
  Loader2,
  ChevronRight
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const RECHARGE_PLANS = [
  { id: 1, price: 299, validity: "28 Days", data: "1.5GB/day", talktime: "Unlimited" },
  { id: 2, price: 666, validity: "84 Days", data: "1.5GB/day", talktime: "Unlimited" },
  { id: 3, price: 155, validity: "24 Days", data: "1GB Total", talktime: "Unlimited" },
];

export default function RechargePage() {
  const [phoneNumber, setPhoneNumber] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState<'details' | 'plans'>('details');
  const { toast } = useToast();
  const router = useRouter();

  const handleProceed = (e: React.FormEvent) => {
    e.preventDefault();
    if (phoneNumber.length < 10) {
      toast({ variant: "destructive", title: "Invalid number" });
      return;
    }
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      setStep('plans');
    }, 1000);
  };

  const handleSelectPlan = (plan: any) => {
    // Navigate to transfer with plan details
    const params = new URLSearchParams();
    params.set('upi', 'recharge@payzen');
    params.set('name', `Mobile Recharge: ${phoneNumber}`);
    params.set('amount', plan.price.toString());
    params.set('note', `Plan: ${plan.data}, ${plan.validity}`);
    router.push(`/transfer?${params.toString()}`);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => step === 'plans' ? setStep('details') : router.back()} className="rounded-full">
          <ArrowLeft className="w-6 h-6" />
        </Button>
        <h1 className="text-2xl font-bold">Mobile Recharge</h1>
      </div>

      {step === 'details' ? (
        <Card className="border-none shadow-xl">
          <CardHeader>
            <CardTitle className="text-lg">Enter Mobile Details</CardTitle>
            <CardDescription>Recharge your mobile instantly with PayZen</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <form onSubmit={handleProceed} className="space-y-4">
              <div className="space-y-2">
                <Label>Phone Number</Label>
                <div className="relative">
                  <Smartphone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                  <Input 
                    type="tel"
                    placeholder="Enter 10-digit number"
                    className="h-14 pl-12 rounded-xl text-lg"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value.replace(/\D/g, '').slice(0, 10))}
                    required
                  />
                </div>
              </div>
              <Button type="submit" className="w-full h-14 rounded-full text-lg" disabled={isProcessing}>
                {isProcessing ? <Loader2 className="animate-spin" /> : "Proceed to Plans"}
              </Button>
            </form>
            
            <div className="space-y-3 pt-4 border-t">
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Recent Recharges</p>
              <div className="bg-slate-50 p-4 rounded-xl flex items-center justify-between cursor-pointer hover:bg-slate-100 transition-colors">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-primary">
                    <Smartphone className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold text-sm">9876543210</p>
                    <p className="text-[10px] text-muted-foreground">Jio Pre-paid • Last recharged 15 days ago</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4 animate-in slide-in-from-right-4">
          <div className="bg-primary/5 p-4 rounded-2xl flex items-center justify-between border border-primary/10">
            <div>
              <p className="text-xs text-muted-foreground">Mobile Number</p>
              <p className="font-bold text-lg">{phoneNumber}</p>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setStep('details')} className="text-primary font-bold">Edit</Button>
          </div>

          <div className="space-y-3">
             <h3 className="font-bold">Recommended Plans</h3>
             {RECHARGE_PLANS.map(plan => (
               <div 
                 key={plan.id} 
                 onClick={() => handleSelectPlan(plan)}
                 className="bg-white p-5 rounded-2xl border-2 border-transparent hover:border-primary/50 cursor-pointer shadow-sm transition-all group"
               >
                 <div className="flex justify-between items-start mb-2">
                   <div className="flex items-baseline gap-1">
                     <span className="text-2xl font-bold">₹{plan.price}</span>
                   </div>
                   <Zap className="w-5 h-5 text-accent opacity-0 group-hover:opacity-100 transition-opacity" />
                 </div>
                 <div className="grid grid-cols-3 gap-4 text-xs">
                    <div>
                      <p className="text-muted-foreground">Validity</p>
                      <p className="font-bold">{plan.validity}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Data</p>
                      <p className="font-bold">{plan.data}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Talktime</p>
                      <p className="font-bold">{plan.talktime}</p>
                    </div>
                 </div>
               </div>
             ))}
          </div>
        </div>
      )}
    </div>
  );
}
