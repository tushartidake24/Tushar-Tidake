
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { 
  ShieldCheck, 
  Smartphone, 
  ArrowRight, 
  Building2, 
  User, 
  Wallet, 
  Zap, 
  Tv, 
  Droplets, 
  Flame,
  CreditCard,
  History,
  Info
} from "lucide-react";
import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";

export default function LandingPage() {
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-payment');

  const transferFeatures = [
    { icon: User, label: "To Mobile Number" },
    { icon: Building2, label: "To Bank/UPI ID" },
    { icon: History, label: "To Self Account" },
    { icon: Wallet, label: "Check Balance" },
  ];

  const billFeatures = [
    { icon: Smartphone, label: "Mobile Recharge", color: "text-blue-500" },
    { icon: Tv, label: "DTH", color: "text-purple-500" },
    { icon: Zap, label: "Electricity", color: "text-yellow-500" },
    { icon: CreditCard, label: "Credit Card", color: "text-red-500" },
  ];

  return (
    <div className="flex flex-col min-h-screen bg-[#f5f5f5]">
      {/* PhonePe Inspired Header */}
      <header className="px-6 h-16 flex items-center justify-between sticky top-0 bg-primary text-white z-50 shadow-md">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center">
            <span className="text-primary font-black text-2xl">U</span>
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight leading-none">UPI-Payment</span>
            <span className="text-[10px] opacity-80 uppercase tracking-widest font-bold">Payments made easy</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/login">
            <Button variant="ghost" className="text-white hover:bg-white/10 font-bold">Login</Button>
          </Link>
          <Link href="/register">
            <Button className="bg-white text-primary hover:bg-white/90 font-bold rounded-full px-6">
              Sign Up
            </Button>
          </Link>
        </div>
      </header>

      <main className="flex-1">
        {/* Modern Hero Section */}
        <section className="bg-primary pt-12 pb-24 px-6 text-white text-center overflow-hidden relative">
          <div className="max-w-4xl mx-auto space-y-6 relative z-10">
            <h1 className="text-4xl md:text-6xl font-black tracking-tight leading-tight">
              India's Favourite <br />
              <span className="text-white/80">Payments App</span>
            </h1>
            <p className="text-lg opacity-80 max-w-xl mx-auto font-medium">
              Join millions of Indians who use UPI-Payment for all their digital payment needs. Fast, safe, and secure.
            </p>
            <div className="pt-4 flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/register">
                <Button size="lg" className="bg-accent hover:bg-accent/90 text-white rounded-full px-10 h-14 text-lg font-bold shadow-xl shadow-black/20">
                  Get Started <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Decorative elements */}
          <div className="absolute -bottom-20 left-1/2 -translate-x-1/2 w-[120%] h-40 bg-[#f5f5f5] rounded-[100%] blur-xl opacity-20"></div>
        </section>

        {/* Feature Grid - Inspired by PhonePe Mobile Interface */}
        <section className="px-6 -mt-12 max-w-5xl mx-auto pb-20">
          <div className="space-y-8">
            
            {/* Money Transfer Section */}
            <div className="bg-white rounded-3xl shadow-xl p-6 md:p-8 border border-slate-100 overflow-hidden relative">
               <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-black text-slate-800 uppercase tracking-wider">Transfer Money</h3>
                  <div className="w-10 h-1 bg-primary/20 rounded-full"></div>
               </div>
               <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                 {transferFeatures.map((f, i) => (
                   <div key={i} className="flex flex-col items-center gap-3 group cursor-pointer">
                      <div className="w-16 h-16 bg-primary/5 rounded-3xl flex items-center justify-center text-primary transition-all group-hover:scale-110 group-hover:bg-primary group-hover:text-white shadow-sm">
                        <f.icon className="w-8 h-8" />
                      </div>
                      <span className="text-xs font-bold text-center text-slate-600 group-hover:text-primary leading-tight">{f.label}</span>
                   </div>
                 ))}
               </div>
            </div>

            {/* Recharge & Bills Section */}
            <div className="bg-white rounded-3xl shadow-xl p-6 md:p-8 border border-slate-100">
               <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-black text-slate-800 uppercase tracking-wider">Recharge & Pay Bills</h3>
                  <div className="w-10 h-1 bg-primary/20 rounded-full"></div>
               </div>
               <div className="grid grid-cols-4 md:grid-cols-4 gap-6">
                 {billFeatures.map((f, i) => (
                   <div key={i} className="flex flex-col items-center gap-3 group cursor-pointer">
                      <div className={`w-14 h-14 bg-slate-50 rounded-2xl flex items-center justify-center ${f.color} transition-all group-hover:scale-105 shadow-sm border border-slate-100`}>
                        <f.icon className="w-6 h-6" />
                      </div>
                      <span className="text-[10px] md:text-xs font-bold text-center text-slate-500 group-hover:text-primary leading-tight">{f.label}</span>
                   </div>
                 ))}
               </div>
               <Button variant="ghost" className="w-full mt-6 text-primary font-bold text-sm hover:bg-primary/5 rounded-xl">
                 See All Payment Services <ArrowRight className="ml-2 w-4 h-4" />
               </Button>
            </div>

            {/* AI Highlight Banner */}
            <div className="bg-gradient-to-r from-purple-800 to-indigo-900 rounded-3xl p-8 text-white flex flex-col md:flex-row items-center gap-8 shadow-2xl relative overflow-hidden">
               <div className="absolute top-0 right-0 p-4 opacity-10">
                  <ShieldCheck className="w-32 h-32" />
               </div>
               <div className="flex-1 space-y-4 relative z-10">
                  <div className="inline-flex items-center gap-2 bg-white/20 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest">
                    <Zap className="w-3 h-3 text-accent" /> Powered by AI Vision
                  </div>
                  <h3 className="text-2xl md:text-3xl font-bold leading-tight">Secure Scan with <br />Smart AI Validation</h3>
                  <p className="text-white/70 text-sm max-w-md">Our advanced AI Vision decodes any UPI QR code instantly, ensuring you pay the right person every single time.</p>
                  <Link href="/scan">
                    <Button className="bg-white text-primary rounded-full hover:bg-white/90 font-bold px-8 mt-2">Try Scanner Now</Button>
                  </Link>
               </div>
               <div className="w-full md:w-64 aspect-square bg-white/10 rounded-3xl backdrop-blur-md flex items-center justify-center relative group">
                  <Smartphone className="w-32 h-32 text-white/20 absolute" />
                  <div className="w-48 h-48 border-2 border-white/50 rounded-2xl flex items-center justify-center animate-pulse">
                     <div className="w-12 h-1 bg-white absolute top-0"></div>
                  </div>
               </div>
            </div>

            {/* Trust Section */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
               {[
                 { title: "24/7 Support", desc: "Always here for your queries", icon: Info },
                 { title: "Zero Fees", desc: "Direct UPI to Bank transfers", icon: Wallet },
                 { title: "Ironclad Security", desc: "Verified merchant scanning", icon: ShieldCheck }
               ].map((item, i) => (
                 <div key={i} className="bg-slate-50 p-6 rounded-2xl flex items-start gap-4 border border-slate-200">
                    <div className="w-10 h-10 bg-white rounded-xl shadow-sm flex items-center justify-center text-primary shrink-0">
                      <item.icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-800 text-sm">{item.title}</h4>
                      <p className="text-xs text-slate-500">{item.desc}</p>
                    </div>
                 </div>
               ))}
            </div>

          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-slate-200 py-12 px-6">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex flex-col items-center md:items-start gap-2">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-primary rounded flex items-center justify-center">
                <span className="text-white font-bold text-xs">U</span>
              </div>
              <span className="text-lg font-bold text-primary">UPI-Payment</span>
            </div>
            <p className="text-xs text-slate-400">© {new Date().getFullYear()} UPI-Payment Digital. India's Favourite App.</p>
          </div>
          <div className="flex gap-8 text-sm font-bold text-slate-600 uppercase tracking-widest">
            <Link href="#" className="hover:text-primary">About</Link>
            <Link href="#" className="hover:text-primary">Security</Link>
            <Link href="#" className="hover:text-primary">Support</Link>
          </div>
          <div className="flex gap-4">
             <ShieldCheck className="w-8 h-8 text-slate-300" />
             <Building2 className="w-8 h-8 text-slate-300" />
          </div>
        </div>
      </footer>
    </div>
  );
}
