'use server';
/**
 * @fileOverview A Genkit flow for validating and decoding UPI QR codes from images using AI Vision.
 *
 * - validateQrCodePayment - A function that handles the QR code scanning and validation.
 * - QrCodePaymentValidationInput - The input type containing the image data.
 * - QrCodePaymentValidationOutput - The extracted payment details.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const QrCodePaymentValidationInputSchema = z.object({
  photoDataUri: z.string().describe("A photo of a QR code, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."),
});
export type QrCodePaymentValidationInput = z.infer<typeof QrCodePaymentValidationInputSchema>;

const QrCodePaymentValidationOutputSchema = z.object({
  isValidUpiQr: z.boolean().describe('True if the image contains a valid UPI payment QR code.'),
  upiId: z.string().nullable().describe('The extracted UPI ID (pa parameter), or null if not found.'),
  payeeName: z.string().nullable().describe('The extracted payee name (pn parameter), or null if not found.'),
  validationMessage: z.string().describe('A message detailing the scan result, e.g., "Merchant Verified" or "No QR code detected".'),
});
export type QrCodePaymentValidationOutput = z.infer<typeof QrCodePaymentValidationOutputSchema>;

export async function validateQrCodePayment(input: QrCodePaymentValidationInput): Promise<QrCodePaymentValidationOutput> {
  return qrCodePaymentValidationFlow(input);
}

const qrCodePaymentValidationPrompt = ai.definePrompt({
  name: 'qrCodePaymentValidationPrompt',
  input: { schema: QrCodePaymentValidationInputSchema },
  output: { schema: QrCodePaymentValidationOutputSchema },
  prompt: `You are an expert at interpreting UPI QR codes from visual data.
Your task is to analyze the provided photo and find any UPI payment QR code.

1. Locate the QR code in the image.
2. Decode the content. A valid UPI URL starts with 'upi://pay?'.
3. Extract the 'pa' (UPI ID) and 'pn' (Payee Name) parameters.
4. If a valid UPI QR is found, set 'isValidUpiQr' to true and return the details.
5. If no QR is found or it's not a UPI QR, set 'isValidUpiQr' to false and explain why in 'validationMessage'.

Photo: {{media url=photoDataUri}}`,
});

const qrCodePaymentValidationFlow = ai.defineFlow(
  {
    name: 'qrCodePaymentValidationFlow',
    inputSchema: QrCodePaymentValidationInputSchema,
    outputSchema: QrCodePaymentValidationOutputSchema,
  },
  async (input) => {
    const { output } = await qrCodePaymentValidationPrompt(input);
    return output!;
  }
);
