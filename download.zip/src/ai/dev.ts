import { config } from 'dotenv';
config();

import '@/ai/flows/qr-code-payment-validation.ts';